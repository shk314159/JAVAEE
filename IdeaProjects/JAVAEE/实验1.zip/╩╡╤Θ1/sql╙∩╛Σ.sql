-- 创建用户 
CREATE USER 'dbuser'@'localhost' IDENTIFIED BY 'dbpassword';

GRANT SELECT, INSERT, UPDATE, DELETE, CREATE ON `mydb`.* TO 'dbuser'@'localhost';

GRANT GRANT OPTION ON `mydb`.* TO 'dbuser'@'localhost';

-- 创建表
CREATE TABLE `NewTable` (
`username`  char(10) NULL ,
`password`  char(10) NULL ,
`type`  int NULL 
)
;
-- 插入数据
INSERT usertable VALUES('zjut','zjut','1')
INSERT usertable VALUES('admin','admin','1')
INSERT usertable VALUES('Temp','temp','2') 