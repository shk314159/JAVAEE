package cn.edu.zjut.dao;
import java.sql.*;import javax.sql.*;import javax.naming.*;
import cn.edu.zjut.model.UserBean;
public class UserDAO {
    private static final String GET_ONE_SQL =
            "SELECT * FROM usertable WHERE username=? and password=?";
    public UserDAO( ){ }
    public Connection getConnection(){
        Connection conn = null;
        String driver = "com.mysql.cj.jdbc.Driver";
        String dburl = "jdbc:mysql://localhost:3306/mydb?serverTimezone=GMT%2B8";
        String username = "dbuser"; //数据库登录用户名
        String password = "dbpassword"; //数据库登录密码
        try{
            Class.forName(driver); //加载数据库驱动程序
            conn = DriverManager.getConnection(dburl,username,password);
        }catch( Exception e ){ e.printStackTrace(); }
        return conn;
    }
    public boolean searchUser(UserBean user){
        // 按用户名和密码校验用户是否合法
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rst=null;
        try{
            conn = getConnection();
            pstmt = conn.prepareStatement("SELECT username FROM usertable WHERE username = ? AND password = ? AND type = ?");
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setInt(3, user.getType());
            rst = pstmt.executeQuery();
            if(rst.next()){
                return true;
            }
        }catch(SQLException se){
            se.printStackTrace();
            return false;
        }finally{
            try{
                pstmt.close();
                conn.close();
            }catch(SQLException se){ se.printStackTrace(); }
        }
        return false;
    }

    public boolean InsertUser(UserBean user){
        // 按用户名和密码校验用户是否合法
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rst=null;
        try{
            String sqlStr = "SELECT username FROM usertable WHERE username = ?";
            conn = getConnection();
            pstmt = conn.prepareStatement(sqlStr);
            pstmt.setString(1, user.getUsername());
            rst = pstmt.executeQuery();
            if(rst.next()) {
                return false;
            }
            sqlStr = "INSERT INTO usertable values('"+user.getUsername()+"','"+user.getPassword()+"','"+user.getType()+"')";
            conn =  getConnection();
            Statement st = conn.createStatement();
            st.setMaxRows(20);
            System.out.println(sqlStr);
            st.executeUpdate(sqlStr);
            return true;
        }catch(SQLException se){
            se.printStackTrace();
            return false;
        }
    }
}