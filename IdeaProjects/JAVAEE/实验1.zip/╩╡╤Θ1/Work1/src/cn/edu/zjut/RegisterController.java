package cn.edu.zjut;

import cn.edu.zjut.dao.UserDAO;
import cn.edu.zjut.model.UserBean;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class RegisterController extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String type = request.getParameter("type");
        UserBean user=new UserBean();
        user.setUsername(username);
        user.setPassword(password);
        if(type.equals("管理员")) user.setType(1);
        else user.setType(0);
        UserDAO dao = new UserDAO();
        if(dao.InsertUser(user)) {
            request.setAttribute("message", "注册成功！");
        }
        else {
            System.out.println("test");
            request.setAttribute("message", "注册失败！");
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher("/RegisterAns.jsp");
        dispatcher.forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
